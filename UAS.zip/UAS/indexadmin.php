<!doctype html>
<html class="no-js" lang="en">
<head>   
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Go Sehat</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <style>
        .carousel-inner>.item>img,
        .carousel-inner>.item>a>img {
            width: 80%;
            margin: auto;
        }
    </style>
    <link rel="shortcut icon" type="image/png" href="assets/images/icon/favicon.ico">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
    <!-- amchart css -->
    <link rel="stylesheet" href="https://www.amcharts.com/lib/3/plugins/export/export.css" type="text/css"
        media="all" />
    <!-- others css -->
    <link rel="stylesheet" href="assets/css/typography.css">
    <link rel="stylesheet" href="assets/css/default-css.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- modernizr css -->
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

<body>
<?php 
    include "koneksi.php";
    session_start();
    if ($_SESSION['status_login'] == 'admin_login') {
?>

    <a href="indexadmin.php"></a>

    <div id="preloader">
        <div class="loader"></div>
    </div>

    <div class="page-container">
        <!-- sidebar menu area start -->
        <div class="sidebar-menu">
            <div class="sidebar-header">
                <div class="logo">
                    <a href="index.php"><img src="assets/images/icon/logo.png" alt="logo" style="width: 100%;"></a>
                </div>
            </div>
            <div class="main-menu">
                <div class="menu-inner">
                    <nav>
                        <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="indexadmin.php" href="javascript:void(0)" aria-expanded="true"><i
                                        class="ti-home"></i><span>Home</span></a>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i
                                        class="ti-shopping-cart-full"></i><span>Inputan
                                    </span></a>
                                <ul>
                                    <li><a href="inputkaryawan.php">Karyawan</a></li>
                                    <li><a href="addBarang.php">Barang</a></li>
                                    <li><a href="datapembelian.php">List Data Penjualan</a></li>
                                    <li><a href="dataBarang.php">List Data Barang</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="datakaryawan.php" href="javascript:void(0)" aria-expanded="true"><i
                                        class="ti-user"></i><span>Data Karyawan</span></a>
                            </li>
                            <li>
                                <a href="infoadmin.php" href="javascript:void(0)" aria-expanded="true"><i
                                        class="ti-info-alt"></i><span>Info</span></a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
        <!-- sidebar menu area end -->
        <!-- main content area start -->
        <div class="main-content">
            <!-- header area start -->
            <div class="header-area">
                <div class="row align-items-center">
                    <!-- nav and search button -->
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="nav-btn pull-left">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div class="search-box pull-left">
                            <form action="#">
                                <input type="text" name="search" placeholder="Search..." required>
                                <i class="ti-search"></i>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <!-- header area end -->
            <!-- page title area start -->
            <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="index.html">Home</a></li>
                                <li><span>Dashboard</span></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img class="avatar user-thumb" src="assets/images/author/avatar.png" alt="avatar">
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown">Dwike<i
                                    class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="logoutAdmin.php">Log Out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="main-content-inner">
                <div class="sales-report-area mt-5 mb-5">
                    <div class="row">
                        <div class="col-md-4">
                            <img src="assets/img/stimuno.jpg" alt="">
                        </div>
                        <div class="col-md-4">
                            <img src="assets/img/safecare.jpg" alt="">
                        </div>
                        <div class="col-md-4">
                            <div class="single-report">
                                <img src="assets/img/diabetadex.jpg" alt="">
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row content-box m-t-30">
                    <div class="col-md-12">
                        <div id="listpopuler" class="home-topic-box-new">
                            <div class="d-flex justify-content-between flex-row mb-2">
                                <div class="d-flex justify-content-start">
                                    <h2>Produk Populer</h2>
                                </div>
                            </div>
                        </div>
                        <div
                            class="product-terpopuler promo-carousel-4 owl-carousel owl-theme promo-carousel owl-loaded owl-drag">
                            <div class="owl-stage-outer">
                                <div class="owl-stage-outer">
                                    <div class="owl-stage"
                                        style="transform: translate3d(0px, 0px, 0px); transition: all 0s ease 0s; width: 2078px;">
                                        <div class="owl-item active" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3" style="height: 360px;"><a href="#"><img
                                                            alt="STIMUNO FORTE BOX 30 KAPSUL"
                                                            data-src="https://img.goapotik.com/mediums/stimuno-30-kapsul-.jpg"
                                                            src="https://img.goapotik.com/mediums/stimuno-30-kapsul-.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2">STIMUNO FORTE BOX 30 KAPSUL</p>
                                                        <div><br><br>
                                                            <p class="card-text-2" style="padding-top: 12px;">Rp. 2.650
                                                            </p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3"><a href="#"><img
                                                            alt="SAFE CARE MINYAK ANGIN AROMATHERAPHY ROLL ON 10 ML"
                                                            data-src="https://img.goapotik.com/mediums/safe-care-minyak_angin_aromatherapy_10_ml_roll_on_1-79.jpg"
                                                            src="https://img.goapotik.com/mediums/safe-care-minyak_angin_aromatherapy_10_ml_roll_on_1-79.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2">SAFE CARE MINYAK ANGIN
                                                            AROMATHERAPHY ROLL ON 10 ML</p>
                                                        <div>
                                                            <p class="card-text-2">Rp. 14.400</p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3"><a
                                                        href="#"><img
                                                            alt="GOLDEN GINGER FLIPTOP SUGAR FREE CLASSIC GINGERINE 45 GRAM"
                                                            data-src="https://img.goapotik.com/mediums/golden_ginger_fliptop_sugar_free_classic_gingerine_45_gram_1.jpg"
                                                            src="https://img.goapotik.com/mediums/golden_ginger_fliptop_sugar_free_classic_gingerine_45_gram_1.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2">GOLDEN GINGER FLIPTOP SUGAR
                                                            FREE CLASSIC GINGERINE 45 GRAM</p>
                                                        <div>
                                                            <p class="card-text-2">Rp. 20.700</p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3"><a
                                                        href="#"><img
                                                            alt="DANCOW 3+ EXCELNUTRI+ USIA 3-5 TAHUN RASA MADU 800 GRAM BOX"
                                                            data-src="https://img.goapotik.com/mediums/dancow_3-5_tahun_800_gram_rasa_madu.jpg"
                                                            src="https://img.goapotik.com/mediums/dancow_3-5_tahun_800_gram_rasa_madu.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2">DANCOW 3+ EXCELNUTRI+ USIA 3-5
                                                            TAHUN RASA MADU 800 GRAM BOX</p>
                                                        <div>
                                                            <p class="card-text-2">Rp. 84.000</p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item active" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3" style="height: 360px;"><a
                                                        href="#"><img
                                                            alt="NUTRINIDRINK RASA VANILA 1-12 TAHUN 400 GRAM KALENG"
                                                            data-src="https://img.goapotik.com/mediums/NUTRINIDRINK-RASA-VANILA-1-12-TAHUN-400-GRAM-KALENG-1.jpg"
                                                            src="https://img.goapotik.com/mediums/NUTRINIDRINK-RASA-VANILA-1-12-TAHUN-400-GRAM-KALENG-1.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2">NUTRINIDRINK RASA VANILA 1-12
                                                            TAHUN 400 GRAM KALENG</p>
                                                        <div><br>
                                                            <p class="card-text-2" style="padding-top: 5px;">Rp. 164.000
                                                            </p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3" style="height: 360px;"><a
                                                        href="#"><img
                                                            alt="LACTOGROW 3 USIA 1-3 TAHUN RASA MADU 750 GRAM BOX"
                                                            data-src="https://img.goapotik.com/mediums/LACTOGROW-3-USIA-1-3-TAHUN-RASA-MADU-750-GRAM-BOX-1.jpg"
                                                            src="https://img.goapotik.com/mediums/LACTOGROW-3-USIA-1-3-TAHUN-RASA-MADU-750-GRAM-BOX-1.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2" style="padding-top: 25px;">
                                                            LACTOGROW 3 USIA 1-3 TAHUN RASA
                                                            MADU 750 GRAM BOX</p>
                                                        <div>
                                                            <p class="card-text-2">Rp. 90.500</p>
                                                        </div>
                                                    </a></div>
                                            </div>
                                        </div>
                                        <div class="owl-item" style="width: 187.76px; margin-right: 20px;">
                                            <div class="item card border-0 shadow-sm mb-1 h-home">
                                                <div class="p-3" style="height: 360px;"><a
                                                        href="#"><img
                                                            alt="MERRIES POPOK CELANA GOOD SKIN UKURAN L PACK 30 PCS"
                                                            data-src="https://img.goapotik.com/mediums/MERRIES-POPOK-CELANA-GOOD-SKIN-UKURAN-L-PACK-30-PCS-1.jpg"
                                                            src="https://img.goapotik.com/mediums/MERRIES-POPOK-CELANA-GOOD-SKIN-UKURAN-L-PACK-30-PCS-1.jpg"
                                                            lazy="loaded"><br>
                                                        <p class="card-text crop-text-2" style="padding-top: 25px;">
                                                            MERRIES POPOK CELANA GOOD SKIN
                                                            UKURAN L PACK 30 PCS</p>
                                                        <div>
                                                            <p class="card-text-2">Rp. 56.764</p>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- row area end -->
                        <div class="row mt-5">
                            <!-- latest news area start -->
                            <div class="col-xl-6">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">New Arrival</h4>
                                        <div class="letest-news mt-5">
                                            <div class="single-post mb-xs-40 mb-sm-40">
                                                <div class="lts-thumb">
                                                    <img src="assets/img/obat1.jpeg" alt="">
                                                </div>
                                                <div class="lts-content">
                                                    <h2><a href="#">Antasida Doen</a>
                                                    </h2>
                                                    <p>Terdapat 2 jenis sediaan, yaitu tablet dan syrup, dalam satu
                                                        sendok takar (5 ml) atau satu tablet mengandung:<br>

                                                        Alluminium Hidroksida : 200 mg<br>
                                                        Magnesium Hidroksida : 200 mg</p>
                                                </div>
                                            </div>
                                            <div class="single-post">
                                                <div class="lts-thumb">
                                                    <img src="assets/img/obat2.jpeg" alt="post thumb">
                                                </div>
                                                <div class="lts-content">
                                                    <h2><a href="#">Kina Tablet</a>
                                                    </h2>
                                                    <p>Kina adalah obat yang digunakan untuk mengobati penyakit malaria.
                                                        Penyakit ini disebabkan oleh parasit yang dikenal dengan
                                                        plasmodium. Ada empat jenis parasit yang menyebabkan malaria,
                                                        yaitu Plasmodium falciparum, Plasmodium malariae, Plasmodium
                                                        ovale, dan Plasmodium vivax. Parasit tersebut menetap di dalam
                                                        perut nyamuk betina yang terinfeksi dan disebarkan ke manusia
                                                        melalui gigitan nyamuk.</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- latest news area end -->
                            <!-- exchange area start -->
                            <div class="col-xl-6 mt-md-30 mt-xs-30 mt-sm-30">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="header-title">Our Store</h4>
                                        <div class="exhcange-rate mt-5">
                                            <div class="container">
                                                <br>
                                                <div id="WJSlider" class="carousel slide" data-ride="carousel">
                                                    <!-- Indikator yang bulat bulat ituloh gan-->
                                                    <ol class="carousel-indicators">
                                                        <li data-target="#WJSlider" data-slide-to="0" class="active">
                                                        </li>
                                                        <li data-target="#WJSlider" data-slide-to="1"></li>
                                                        <li data-target="#WJSlider" data-slide-to="2"></li>
                                                        <li data-target="#WJSlider" data-slide-to="3"></li>
                                                    </ol>

                                                    <!-- Wrapper untuk slides -->
                                                    <div class="carousel-inner" role="listbox">

                                                        <div class="item active">
                                                            <img src="assets/img/apotik.jpeg" alt="slide1" width="460"
                                                                height="500">
                                                        </div>

                                                        <div class="item">
                                                            <img src="assets/img/apotik1.jpeg" alt="slide2" width="460"
                                                                height="345">
                                                            <div class="carousel-caption">
                                                            </div>
                                                        </div>

                                                        <div class="item">
                                                            <img src="assets/img/apotik2.jpeg" alt="slide3" width="460"
                                                                height="345">
                                                            <div class="carousel-caption">
                                                            </div>
                                                        </div>

                                                        <div class="item">
                                                            <img src="assets/img/apotik3.jpeg" alt="slide4" width="460"
                                                                height="345">
                                                            <div class="carousel-caption">
                                                            </div>
                                                        </div>

                                                    </div>

                                                    <!-- Kode untuk Navigasi -->
                                                    <a class="left carousel-control" href="#WJSlider" role="button"
                                                        data-slide="prev">
                                                        <span class="glyphicon glyphicon-chevron-left"
                                                            aria-hidden="true"></span>
                                                        <span class="sr-only">Kembali</span>
                                                    </a>
                                                    <a class="right carousel-control" href="#WJSlider" role="button"
                                                        data-slide="next">
                                                        <span class="glyphicon glyphicon-chevron-right"
                                                            aria-hidden="true"></span>
                                                        <span class="sr-only">Lanjut</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="card">
                                    <div class="card-body">
                                        <div class="lts-content">
                                            <h2>Info Toko</h2><br>
                                            <p>
                                                <b>Alamat :</b><br> Jl. Soekarno Hatta Ptp I No.66 F, Mojolangu, Kec.
                                                Lowokwaru,
                                                Kota Malang,
                                                Jawa Timur 65142<br>
                                                <b>Jam Buka :</b> Buka 24 jam<br>
                                                <b>Telepon :</b> (0341) 4373903<br>
                                                <b>Provinsi :</b> Jawa Timur
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- exchange area end -->
                        </div>
                        <!-- row area start-->
                    </div>
                </div>
                <!-- main content area end -->
                <!-- footer area start-->
                <br>
                <footer>
                    <div class="footer-area">
                        <p>© Dwike Nafis Malik TI-2F 2019</p>
                    </div>
                </footer>
                <!-- footer area end-->
            </div>
            <!-- offset area end -->
            <!-- jquery latest version -->
            <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
            <!-- bootstrap 4 js -->
            <script src="assets/js/popper.min.js"></script>
            <script src="assets/js/bootstrap.min.js"></script>
            <script src="assets/js/owl.carousel.min.js"></script>
            <script src="assets/js/metisMenu.min.js"></script>
            <script src="assets/js/jquery.slimscroll.min.js"></script>
            <script src="assets/js/jquery.slicknav.min.js"></script>

            <!-- start chart js -->
            <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
            <!-- start highcharts js -->
            <script src="https://code.highcharts.com/highcharts.js"></script>
            <!-- start zingchart js -->
            <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
            <script>
                zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
                ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
            </script>
            <!-- all line chart activation -->
            <script src="assets/js/line-chart.js"></script>
            <!-- all pie chart -->
            <script src="assets/js/pie-chart.js"></script>
            <!-- others plugins -->
            <script src="assets/js/plugins.js"></script>
            <script src="assets/js/scripts.js"></script>

            <?php
    }else{
        header("Refresh:0; url=login.php");
    }
?>
</body>

</html>