<?php 
	include "koneksi.php";

	$username = $_GET['nama_user'];
	$query = "DELETE from user where nama_user = '$username'";
	$result = mysqli_query($connect, $query);

	if ($result) {
		header("location: datakaryawan.php");
	}

 ?>