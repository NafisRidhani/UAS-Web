<?php 
    include 'koneksi.php';

    $username=$_POST['username'];
    $password=md5($_POST['password']);

    $query="SELECT * from user where username='$username' and password='$password' ";
    $result=mysqli_query($connect, $query);
    $cek=mysqli_num_rows($result);

    if ($cek > 0) {
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['password'] = $password;
        ?>
       <!--  <script type="text/javascript" src="jquery-3.4.1.js"></script>
    <srcript>
    $(document).ready(function(){
        alert("Berhasil login");
    });
    </srcript> --><?php
   header("Refresh:2; url=index.php");
    }else{
        header("Refresh:1; url=loginkasir.php");
    }
 ?>