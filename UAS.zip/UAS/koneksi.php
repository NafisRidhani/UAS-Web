<?php 
	$namaHost = "localhost";
    $username = "root";
    $password = "";
    $database = "db_apotek";

    $connect = mysqli_connect($namaHost, $username, $password, $database);
 ?>