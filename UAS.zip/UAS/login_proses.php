<?php 
    include 'koneksi.php';

    $username=$_POST['username'];
    $password=md5($_POST['password']);



    $query="SELECT * from admin where username='$username' and password='$password' ";
    $result=mysqli_query($connect, $query);
    $cek=mysqli_num_rows($result);


    if ($cek > 0) {
        session_start();
        $_SESSION['username'] = $username;
        $_SESSION['status_login'] = 'admin_login';
       
        header("location: indexadmin.php");
    
    }else{
        $msq = "passed";
        echo "<script>alert('Pastikan anda terdaftar dan input data dengan benar !');
        window.location.href = 'loginadmin.php';
        </script>";
    }
 ?>