<html>

<head>
    <title>Register Status</title>
</head>

<body>
    <?php
    include "koneksi.php";

    $username = $_POST['username'];
    $password = $_POST['password'];
    $nama_admin = $_POST['nama_admin'];
    $alamat_admin = $_POST['alamat_admin'];
    $email = $_POST['email'];
    $nohp = $_POST['nohp'];


    $sqlCheck = "SELECT * FROM admin where username='$username' AND password='$password'";
    $runCheck = mysqli_query($connect, $sqlCheck);

    $checkAvailability = mysqli_num_rows($runCheck);

    if ($checkAvailability == TRUE) {
        ?>
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Username or Email already Exist',
                showConfirmButton: false,
                timer: 2000
            })
        </script>
        <?php
            header("Refresh:1; url=Register.php");
        } else {
            $sql = "INSERT INTO `admin` (`username`, `password`, `nama_admin`, `alamat_admin`, `email`, `nohp`) VALUES ('$username', MD5('$password'), '$nama_admin', '$alamat_admin', '$email', '$nohp')";
            if (mysqli_query($connect, $sql)) {
                ?>
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Success Register',
                    showConfirmButton: false,
                    timer: 2000
                })
            </script>
        <?php
                header("Refresh:2; url=loginadmin.php");
            } else {
                ?>
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Error Connect MySQL',
                    showConfirmButton: false,
                    timer: 2000
                })
            </script>
    <?php
            header("Refresh:1; url=Register.php");
        }
        mysqli_close($connect);
    } ?>
</body>

</html>