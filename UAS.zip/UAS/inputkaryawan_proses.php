<?php
include "koneksi.php";
if(isset($_POST['submit'])){
    $nama = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $alamat = $_POST['alamat'];
    $jabatan = $_POST['jabatan'];           
    $ttl = $_POST['ttl'];
    $nohp = $_POST['nohp'];
    $email = $_POST['email'];
    $ekstensi_diperbolehkan = array('png','jpg');
    $uploadedfile = $_FILES['uploadedfile']['name'];
    $x = explode('.', $uploadedfile);
    $ekstensi = strtolower(end($x));
    $ukuran = $_FILES['uploadedfile']['size'];
    $file_tmp = $_FILES['uploadedfile']['tmp_name'];
    if(in_array($ekstensi, $ekstensi_diperbolehkan) === true){
            move_uploaded_file($file_tmp, 'img/karyawan/'.$uploadedfile);
            $query = mysqli_query($connect,"INSERT INTO user (username,Password,nama_user,alamat_user,jabatan,TTL,nohp,email,gambar) VALUES ('$username','$password','$nama','$alamat','$jabatan','$ttl','$nohp','$email','$uploadedfile')");
            echo $query;
            if($query){
                $msq = "Berhasil Input data";
                echo "<script>alert('$msq');
                window.location.href = 'datakaryawan.php';
                </script>";
            }else{
                echo $connect->error;
                echo $query;
                echo 'GAGAL MENGUPLOAD GAMBAR';

            }
        }else{
        echo 'EKSTENSI FILE YANG DI UPLOAD TIDAK DI PERBOLEHKAN';
        }
    }
function ListAdmin()
{
    include 'koneksi.php';
    $query = "SELECT * FROM admin ORDER BY nama_user";
    return $connect->query($query);
}
function ListAdminByID($id)
{
    include 'koneksi.php';
    $query = "SELECT id_admin, nama_admin, alamat_admin, email, nohp FROM `admin` WHERE id_admin = '$id'";
    return $connect->query($query);
}
function AddKasir($nama, $alamat, $jabatan, $ttl, $email, $nohp)
{
    include 'koneksi.php';
    $query = "INSERT INTO user (nama_user, alamat_user, jabatan, TTL, email, nohp ) VALUES ('$nama', '$alamat', '$jabatan', '$ttl', '$email', 'nohp')";
    echo $query;
    if ($connect->query($query) == TRUE) {
        $connect->close();
        header("Location:datakaryawan.php");
    } else {
        $message = "gagal input data" . mysqli_error($connect);
        echo "<script type='text/javascript'>alert('$message');</script>";
        echo $message;
    }
}
function DeleteKasir($id)
{
    include 'koneksi.php';
    $query = "DELETE FROM 'user' WHERE id_user = '$id'";
    if ($connect->query($query) == TRUE) {
        $connect->close();
        header("Location:datakaryawan.php");
    } else {
        $message = "gagal input data" . mysqli_error($connect);
        echo "<script type='text/javascript'>alert('$message');</script>";
        echo $message;
    }
}
if (isset($_POST['submitAdd'])) {
    $nama = $_POST['nama_puskesmas'];
    $alamat = $_POST['alamat_puskesmas'];
    $telp = $_POST['telepon_puskesmas'];
    $jenis = 1;
    if ($_POST['select_puskesmas'] == "Rawat Inap") {
        $jenis = 1;
    } elseif ($_POST['select_puskesmas'] == "Non Rawat Inap") {
        $jenis = 2;
    }
    AddPuskesmas($nama, $alamat, $telp, $jenis);
}